#1. TemperatureConversion: Scrie un program care cere utilizatorului input grade Celsius si le converteste
#in grade farenheit.
#Farenheit = Celsius x 9/5 + 32

def ruleaza_conversie_temperatura():
    celsius = float(input("Introdu temperatura în Celsius: "))
    fahrenheit = (celsius * 9 / 5) + 32
    print(f"Rezultat: {fahrenheit} grade Fahrenheit.")

ruleaza_conversie_temperatura()